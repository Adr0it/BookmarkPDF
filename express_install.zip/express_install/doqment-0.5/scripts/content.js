// Auto-open PDFs //
(async () => {
    const response = await chrome.runtime.sendMessage({a: "a"});
})();
////////////////////